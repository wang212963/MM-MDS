#REMOVE DOUBLET
# R VERSION:4.1.0 scDblFinder VERSION :1.6.0
library(scDblFinder)
library(BiocParallel)
sce <- as.SingleCellExperiment(MM_MDS_MERGE) # SEURAT OBJECT MM_MDS_MERGE or MM_MDS_MERGE_NO_MDS
sce <- scDblFinder(sce, samples="orig.ident", BPPARAM=MulticoreParam(3))
table(sce$scDblFinder.class)
MM_MDS_MERGE <- as.Seurat(sce)
DimPlot(MM_MDS_MERGE, group.by = "scDblFinder.class", raster = FALSE)
MM_MDS_MERGE<-subset(MM_MDS_MERGE,scDblFinder.class=="singlet")
