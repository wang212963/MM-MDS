#DOTPLOT FOR CELL ANNOTATION  

list_genes=List(T=c("PTPRC","CD3D","CD3E","CD4","CD8A","CD8B","CCR7","LEF1","GZMK","IL7R"),
                B=c("CD79A", "MS4A1", "CD19","NEIL1"),
                Monocyte=c("CD14", "FCGR3A", "MS4A7","RETN","ELANE"),
                Neutro=c("FCGR3B", "CMTM2"),
                NK=c("NKG7","GNLY", "GZMA","PRF1"),
                PC=c("TNFRSF17","MZB1", "SDC1"),
                MKP=c("PPBP","PF4" ),
                ERYTHO=c("AHSP","HBA2","HBB"),
                Stromal=c("VCAM1"),
                DC=c("CLEC4C","CLEC10A"),
                HSC=c("CD34"))

p1<-DotPlot(MM_MDS_MERGE_NO_MDS,
            features=list_genes,,
            cluster.idents = T,)+
  RotatedAxis()+
  theme(
    # ?????????
    panel.border = element_rect(color="black"), #??????????????
    panel.spacing = unit(1, "mm"), #???????????????
    
    # ?????????????????????
    #strip.background = element_rect(color="red"),
    strip.text = element_text(margin=margin(b=3, unit="mm")),
    strip.placement = 'outlet', #
    
    # ????????????????????????
    axis.line = element_blank(),
  )+labs(x="", y="")+scale_color_gradientn(colours = c('#330066','#336699','#FFCC33')) 
p1