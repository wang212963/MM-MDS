#densitymap

library(cetcolor)
library(Seurat)
library(ggplot2)

# generate UMAP plot
pl1 <- DimPlot(lineage_cells, 
               combine = FALSE # returns full ggplot object
               ,group.by = "CELLTYPE",split.by = "STIM")

# custom color scale
scale.col <- cet_pal(16, name = "fire")

# make plot
pl1[[1]] & 
  stat_density_2d(aes_string(x = "UMAP_1", y = "UMAP_2", fill = "after_stat(level)"), 
                  linewidth = 0.2, geom = "density_2d_filled", 
                  colour = "ivory", alpha = 0.4, n = 150, h = c(1.2, 1.2)) & 
  scale_fill_gradientn(colours = scale.col)