#CELLCHAT
# CellChat version :1.1.3
# R VERSION : 4.1.0
library(CellChat) 
library(tidyverse)
library(ggalluvial)
library(Seurat)
table(MM_MDS_MERGE@meta.data$STIM,MM_MDS_MERGE$CELLTYPE)
HD<-subset(MM_MDS_MERGE,STIM==c("HD"))
MM_high_risk<-subset(MM_MDS_MERGE,STIM==c("MM_high_risk"))
MM_low_risk<-subset(MM_MDS_MERGE,STIM==c("MM_low_risk"))
MDS_high_risk<-subset(MM_MDS_MERGE,STIM==c("MDS_high_risk"))
MDS_low_risk<-subset(MM_MDS_MERGE,STIM==c("MDS_low_risk"))
MM_MDS_high_risk<-subset(MM_MDS_MERGE,STIM==c("MM_MDS_high_risk"))
MM_MDS_low_risk<-subset(MM_MDS_MERGE,STIM==c("MM_MDS_low_risk"))
table(HD$STIM)
#HD_CELLCHAT
DimPlot(HD)
data.input <- GetAssayData(HD, assay = "RNA", slot = "data")
identity <- subset(HD@meta.data, select = "CELLTYPE")
HD_CELLCHAT <- createCellChat(object= data.input)
HD_CELLCHAT <- addMeta(HD_CELLCHAT, meta = identity, meta.name = "labels")
HD_CELLCHAT <- setIdent(HD_CELLCHAT, ident.use = "labels")
groupSize <- as.numeric(table(HD_CELLCHAT@idents))
CellChatDB <- CellChatDB.human
CellChatDB
# ????????"Secreted Signaling"????????????????????????????????????
#CellChatDB.use <- subsetDB(CellChatDB)
#CONTROL_CELLCHAT@DB <- CellChatDB.use
HD_CELLCHAT@DB <- CellChatDB
HD_CELLCHAT <- subsetData(HD_CELLCHAT)
HD_CELLCHAT <- identifyOverExpressedGenes(HD_CELLCHAT)
# ????????????????????-???????????????
HD_CELLCHAT <- identifyOverExpressedInteractions(HD_CELLCHAT)
# ??????????????????]????????????????????PPI????????????
HD_CELLCHAT <- projectData(HD_CELLCHAT, PPI.human)
##????????????????????????????????
HD_CELLCHAT <- computeCommunProb(HD_CELLCHAT)
HD_CELLCHAT<-filterCommunication(HD_CELLCHAT,min.cells = 1)
HD_CELLCHAT <- computeCommunProbPathway(HD_CELLCHAT)
HD_CELLCHAT <- aggregateNet(HD_CELLCHAT)
HD_CELLCHAT@netP$pathways
HD_CELLCHAT <- netAnalysis_computeCentrality(HD_CELLCHAT, slot.name = "netP")
saveRDS(HD_CELLCHAT,file = "HD_CELLCHAT.rds")


#MM_low_risk_CELLCHAT
data.input <- GetAssayData(MM_low_risk, assay = "RNA", slot = "data")
identity <- subset(MM_low_risk@meta.data, select = "CELLTYPE")
MM_low_risk_CELLCHAT <- createCellChat(object= data.input)
MM_low_risk_CELLCHAT <- addMeta(MM_low_risk_CELLCHAT, meta = identity, meta.name = "labels")
MM_low_risk_CELLCHAT <- setIdent(MM_low_risk_CELLCHAT, ident.use = "labels")
groupSize <- as.numeric(table(MM_low_risk_CELLCHAT@idents))
CellChatDB <- CellChatDB.human
CellChatDB
# ????????"Secreted Signaling"????????????????????????????????????
#CellChatDB.use <- subsetDB(CellChatDB)
#CONTROL_CELLCHAT@DB <- CellChatDB.use
MM_low_risk_CELLCHAT@DB <- CellChatDB
MM_low_risk_CELLCHAT <- subsetData(MM_low_risk_CELLCHAT)
MM_low_risk_CELLCHAT <- identifyOverExpressedGenes(MM_low_risk_CELLCHAT)
# ????????????????????-???????????????
MM_low_risk_CELLCHAT <- identifyOverExpressedInteractions(MM_low_risk_CELLCHAT)
# ??????????????????]????????????????????PPI????????????
MM_low_risk_CELLCHAT <- projectData(MM_low_risk_CELLCHAT, PPI.human)
##????????????????????????????????
MM_low_risk_CELLCHAT <- computeCommunProb(MM_low_risk_CELLCHAT)
MM_low_risk_CELLCHAT<-filterCommunication(MM_low_risk_CELLCHAT,min.cells = 1)
MM_low_risk_CELLCHAT <- computeCommunProbPathway(MM_low_risk_CELLCHAT)
MM_low_risk_CELLCHAT <- aggregateNet(MM_low_risk_CELLCHAT)
MM_low_risk_CELLCHAT@netP$pathways
MM_low_risk_CELLCHAT <- netAnalysis_computeCentrality(MM_low_risk_CELLCHAT, slot.name = "netP")
saveRDS(MM_low_risk_CELLCHAT,file = "MM_low_risk_CELLCHAT.rds")


#MM_high_risk_CELLCHAT
data.input <- GetAssayData(MM_high_risk, assay = "RNA", slot = "data")
identity <- subset(MM_high_risk@meta.data, select = "CELLTYPE")
MM_high_risk_CELLCHAT <- createCellChat(object= data.input)
MM_high_risk_CELLCHAT <- addMeta(MM_high_risk_CELLCHAT, meta = identity, meta.name = "labels")
MM_high_risk_CELLCHAT <- setIdent(MM_high_risk_CELLCHAT, ident.use = "labels")
groupSize <- as.numeric(table(MM_high_risk_CELLCHAT@idents))
CellChatDB <- CellChatDB.human
CellChatDB
# ????????"Secreted Signaling"????????????????????????????????????
#CellChatDB.use <- subsetDB(CellChatDB)
#CONTROL_CELLCHAT@DB <- CellChatDB.use
MM_high_risk_CELLCHAT@DB <- CellChatDB
MM_high_risk_CELLCHAT <- subsetData(MM_high_risk_CELLCHAT)
MM_high_risk_CELLCHAT <- identifyOverExpressedGenes(MM_high_risk_CELLCHAT)
# ????????????????????-???????????????
MM_high_risk_CELLCHAT <- identifyOverExpressedInteractions(MM_high_risk_CELLCHAT)
# ??????????????????]????????????????????PPI????????????
MM_high_risk_CELLCHAT <- projectData(MM_high_risk_CELLCHAT, PPI.human)
##????????????????????????????????
MM_high_risk_CELLCHAT <- computeCommunProb(MM_high_risk_CELLCHAT)
MM_high_risk_CELLCHAT<-filterCommunication(MM_high_risk_CELLCHAT,min.cells = 1)
MM_high_risk_CELLCHAT <- computeCommunProbPathway(MM_high_risk_CELLCHAT)
MM_high_risk_CELLCHAT <- aggregateNet(MM_high_risk_CELLCHAT)
MM_high_risk_CELLCHAT@netP$pathways
MM_high_risk_CELLCHAT <- netAnalysis_computeCentrality(MM_high_risk_CELLCHAT, slot.name = "netP")
saveRDS(MM_high_risk_CELLCHAT,file = "MM_high_risk_CELLCHAT.rds")


#MDS_low_risk_CELLCHAT
#DAY28_NON_CR_TPM[["CELLTYPE"]]<-DAY28_NON_CR_TPM@active.ident
data.input <- GetAssayData(MDS_low_risk, assay = "RNA", slot = "data")
identity <- subset(MDS_low_risk@meta.data, select = "CELLTYPE")
MDS_low_risk_CELLCHAT <- createCellChat(object= data.input)
MDS_low_risk_CELLCHAT <- addMeta(MDS_low_risk_CELLCHAT, meta = identity, meta.name = "labels")
MDS_low_risk_CELLCHAT <- setIdent(MDS_low_risk_CELLCHAT, ident.use = "labels")
groupSize <- as.numeric(table(MDS_low_risk_CELLCHAT@idents))
CellChatDB <- CellChatDB.human
CellChatDB
# ????????"Secreted Signaling"????????????????????????????????????
#CellChatDB.use <- subsetDB(CellChatDB)
#CONTROL_CELLCHAT@DB <- CellChatDB.use
MDS_low_risk_CELLCHAT@DB <- CellChatDB
MDS_low_risk_CELLCHAT <- subsetData(MDS_low_risk_CELLCHAT)
MDS_low_risk_CELLCHAT <- identifyOverExpressedGenes(MDS_low_risk_CELLCHAT)
# ????????????????????-???????????????
MDS_low_risk_CELLCHAT <- identifyOverExpressedInteractions(MDS_low_risk_CELLCHAT)
# ??????????????????]????????????????????PPI????????????
MDS_low_risk_CELLCHAT <- projectData(MDS_low_risk_CELLCHAT, PPI.human)
##????????????????????????????????
MDS_low_risk_CELLCHAT <- computeCommunProb(MDS_low_risk_CELLCHAT)
MDS_low_risk_CELLCHAT <-filterCommunication(MDS_low_risk_CELLCHAT,min.cells = 1)
MDS_low_risk_CELLCHAT <- computeCommunProbPathway(MDS_low_risk_CELLCHAT)
MDS_low_risk_CELLCHAT <- aggregateNet(MDS_low_risk_CELLCHAT)
MDS_low_risk_CELLCHAT@netP$pathways
MDS_low_risk_CELLCHAT <- netAnalysis_computeCentrality(MDS_low_risk_CELLCHAT, slot.name = "netP")
saveRDS(MDS_low_risk_CELLCHAT,file = "MDS_low_risk_CELLCHAT.rds")

#MDS_high_risk_CELLCHAT
data.input <- GetAssayData(MDS_high_risk, assay = "RNA", slot = "data")
identity <- subset(MDS_high_risk@meta.data, select = "CELLTYPE")
MDS_high_risk_CELLCHAT <- createCellChat(object= data.input)
MDS_high_risk_CELLCHAT <- addMeta(MDS_high_risk_CELLCHAT, meta = identity, meta.name = "labels")
MDS_high_risk_CELLCHAT <- setIdent(MDS_high_risk_CELLCHAT, ident.use = "labels")
groupSize <- as.numeric(table(MDS_high_risk_CELLCHAT@idents))
CellChatDB <- CellChatDB.human
CellChatDB
# ????????"Secreted Signaling"????????????????????????????????????
#CellChatDB.use <- subsetDB(CellChatDB)
#CONTROL_CELLCHAT@DB <- CellChatDB.use
MDS_high_risk_CELLCHAT@DB <- CellChatDB
MDS_high_risk_CELLCHAT <- subsetData(MDS_high_risk_CELLCHAT)
MDS_high_risk_CELLCHAT <- identifyOverExpressedGenes(MDS_high_risk_CELLCHAT)
# ????????????????????-???????????????
MDS_high_risk_CELLCHAT <- identifyOverExpressedInteractions(MDS_high_risk_CELLCHAT)
# ??????????????????]????????????????????PPI????????????
MDS_high_risk_CELLCHAT <- projectData(MDS_high_risk_CELLCHAT, PPI.human)
##????????????????????????????????
MDS_high_risk_CELLCHAT <- computeCommunProb(MDS_high_risk_CELLCHAT)
MDS_high_risk_CELLCHAT<-filterCommunication(MDS_high_risk_CELLCHAT,min.cells = 1)
MDS_high_risk_CELLCHAT <- computeCommunProbPathway(MDS_high_risk_CELLCHAT)
MDS_high_risk_CELLCHAT <- aggregateNet(MDS_high_risk_CELLCHAT)
MDS_high_risk_CELLCHAT@netP$pathways
MDS_high_risk_CELLCHAT <- netAnalysis_computeCentrality(MDS_high_risk_CELLCHAT, slot.name = "netP")
saveRDS(MDS_high_risk_CELLCHAT,file = "MDS_high_risk_CELLCHAT.rds")


#MM_MDS_low_risk_CELLCHAT
data.input <- GetAssayData(MM_MDS_low_risk, assay = "RNA", slot = "data")
identity <- subset(MM_MDS_low_risk@meta.data, select = "CELLTYPE")
MM_MDS_low_risk_CELLCHAT <- createCellChat(object= data.input)
MM_MDS_low_risk_CELLCHAT <- addMeta(MM_MDS_low_risk_CELLCHAT, meta = identity, meta.name = "labels")
MM_MDS_low_risk_CELLCHAT <- setIdent(MM_MDS_low_risk_CELLCHAT, ident.use = "labels")
groupSize <- as.numeric(table(MM_MDS_low_risk_CELLCHAT@idents))
CellChatDB <- CellChatDB.human
CellChatDB
# ????????"Secreted Signaling"????????????????????????????????????
#CellChatDB.use <- subsetDB(CellChatDB)
#CONTROL_CELLCHAT@DB <- CellChatDB.use
MM_MDS_low_risk_CELLCHAT@DB <- CellChatDB
MM_MDS_low_risk_CELLCHAT <- subsetData(MM_MDS_low_risk_CELLCHAT)
MM_MDS_low_risk_CELLCHAT <- identifyOverExpressedGenes(MM_MDS_low_risk_CELLCHAT)
# ????????????????????-???????????????
MM_MDS_low_risk_CELLCHAT <- identifyOverExpressedInteractions(MM_MDS_low_risk_CELLCHAT)
# ??????????????????]????????????????????PPI????????????
MM_MDS_low_risk_CELLCHAT <- projectData(MM_MDS_low_risk_CELLCHAT, PPI.human)
##????????????????????????????????
MM_MDS_low_risk_CELLCHAT <- computeCommunProb(MM_MDS_low_risk_CELLCHAT)
MM_MDS_low_risk_CELLCHAT<-filterCommunication(MM_MDS_low_risk_CELLCHAT,min.cells = 1)
MM_MDS_low_risk_CELLCHAT <- computeCommunProbPathway(MM_MDS_low_risk_CELLCHAT)
MM_MDS_low_risk_CELLCHAT <- aggregateNet(MM_MDS_low_risk_CELLCHAT)
MM_MDS_low_risk_CELLCHAT@netP$pathways
MM_MDS_low_risk_CELLCHAT <- netAnalysis_computeCentrality(MM_MDS_low_risk_CELLCHAT, slot.name = "netP")
saveRDS(MM_MDS_low_risk_CELLCHAT,file = "MM_MDS_low_risk_CELLCHAT.rds")

#MM_MDS_high_risk_CELLCHAT
data.input <- GetAssayData(MM_MDS_high_risk, assay = "RNA", slot = "data")
identity <- subset(MM_MDS_high_risk@meta.data, select = "CELLTYPE")
MM_MDS_high_risk_CELLCHAT <- createCellChat(object= data.input)
MM_MDS_high_risk_CELLCHAT <- addMeta(MM_MDS_high_risk_CELLCHAT, meta = identity, meta.name = "labels")
MM_MDS_high_risk_CELLCHAT <- setIdent(MM_MDS_high_risk_CELLCHAT, ident.use = "labels")
groupSize <- as.numeric(table(MM_MDS_high_risk_CELLCHAT@idents))
CellChatDB <- CellChatDB.human
CellChatDB
# ????????"Secreted Signaling"????????????????????????????????????
#CellChatDB.use <- subsetDB(CellChatDB)
#CONTROL_CELLCHAT@DB <- CellChatDB.use
MM_MDS_high_risk_CELLCHAT@DB <- CellChatDB
MM_MDS_high_risk_CELLCHAT <- subsetData(MM_MDS_high_risk_CELLCHAT)
MM_MDS_high_risk_CELLCHAT <- identifyOverExpressedGenes(MM_MDS_high_risk_CELLCHAT)
# ????????????????????-???????????????
MM_MDS_high_risk_CELLCHAT <- identifyOverExpressedInteractions(MM_MDS_high_risk_CELLCHAT)
# ??????????????????]????????????????????PPI????????????
MM_MDS_high_risk_CELLCHAT <- projectData(MM_MDS_high_risk_CELLCHAT, PPI.human)
##????????????????????????????????
MM_MDS_high_risk_CELLCHAT <- computeCommunProb(MM_MDS_high_risk_CELLCHAT)
MM_MDS_high_risk_CELLCHAT<-filterCommunication(MM_MDS_high_risk_CELLCHAT,min.cells = 1)
MM_MDS_high_risk_CELLCHAT <- computeCommunProbPathway(MM_MDS_high_risk_CELLCHAT)
MM_MDS_high_risk_CELLCHAT <- aggregateNet(MM_MDS_high_risk_CELLCHAT)
MM_MDS_high_risk_CELLCHAT@netP$pathways
MM_MDS_high_risk_CELLCHAT <- netAnalysis_computeCentrality(MM_MDS_high_risk_CELLCHAT, slot.name = "netP")
saveRDS(MM_MDS_high_risk_CELLCHAT,file = "MM_MDS_high_risk_CELLCHAT.rds")



object.list <- list(HD = HD_CELLCHAT, MM_low_risk = MM_low_risk_CELLCHAT, MM_high_risk = MM_high_risk_CELLCHAT,MDS_low_risk = MDS_low_risk_CELLCHAT, MDS_high_risk = MDS_high_risk_CELLCHAT,MM_MDS_low_risk = MM_MDS_low_risk_CELLCHAT, MM_MDS_high_risk = MM_MDS_high_risk_CELLCHAT)
cellchat <- mergeCellChat(object.list, add.names = names(object.list))

gg1 <- rankNet(cellchat, mode = "comparison", sources.use = NULL, targets.use = NULL, stacked = T, do.stat = TRUE,comparison = c(1,2,3,4,5,6,7),color.use = allcolour)
gg2 <- rankNet(cellchat, mode = "comparison", sources.use = NULL, targets.use = NULL, stacked = F, do.stat = TRUE,comparison = c(1,2,3,4,5,6,7),color.use = allcolour)
gg1+gg2

netVisual_bubble(cellchat, sources.use = c(1:19), targets.use = c(8), comparison = c(1, 2,3,4,5,6,7), angle.x = 45)
netVisual_bubble(cellchat, sources.use = c(1:19), targets.use = c(12), comparison = c(1, 2,3,4,5,6,7), angle.x = 45)

library(ComplexHeatmap)
par(mfrow = c(2,2), xpd=TRUE)
i=1
pathway.union <- union(object.list[[i]]@netP$pathways, c(object.list[[i+1]]@netP$pathways, object.list[[i+2]]@netP$pathways, object.list[[i+3]]@netP$pathways))
ht1 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i], width = 8, height = 16)
ht2 = netAnalysis_signalingRole_heatmap(object.list[[i+1]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i+1], width = 8, height = 16)
ht3 = netAnalysis_signalingRole_heatmap(object.list[[i+2]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i+2], width = 8, height = 16)
ht4 = netAnalysis_signalingRole_heatmap(object.list[[i+3]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i+3], width = 8, height = 16)
ht5 = netAnalysis_signalingRole_heatmap(object.list[[i+4]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i+4], width = 8, height = 16)
ht6 = netAnalysis_signalingRole_heatmap(object.list[[i+5]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i+5], width = 8, height = 16)
ht7 = netAnalysis_signalingRole_heatmap(object.list[[i+6]], pattern = "outgoing", signaling = pathway.union, title = names(object.list)[i+6], width = 8, height = 16)
draw(ht1 + ht2 + ht3 + ht4 + ht5 + ht6 + ht7,ht_gap = unit(0.5, "cm"))

ht1 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i], width = 8, height = 16, color.heatmap = "GnBu")
ht2 = netAnalysis_signalingRole_heatmap(object.list[[i+1]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i+1], width = 8, height = 16, color.heatmap = "GnBu")
ht3 = netAnalysis_signalingRole_heatmap(object.list[[i+2]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i+2], width = 8, height = 16, color.heatmap = "GnBu")
ht4 = netAnalysis_signalingRole_heatmap(object.list[[i+3]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i+3], width = 8, height = 16, color.heatmap = "GnBu")
ht5 = netAnalysis_signalingRole_heatmap(object.list[[i+4]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i+4], width = 8, height = 16, color.heatmap = "GnBu")
ht6 = netAnalysis_signalingRole_heatmap(object.list[[i+5]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i+5], width = 8, height = 16, color.heatmap = "GnBu")
ht7 = netAnalysis_signalingRole_heatmap(object.list[[i+6]], pattern = "incoming", signaling = pathway.union, title = names(object.list)[i+6], width = 8, height = 16, color.heatmap = "GnBu")
draw(ht1 + ht2 + ht3 + ht4 + ht5 + ht6 + ht7, ht_gap = unit(0.5, "cm"))
ht1 = netAnalysis_signalingRole_heatmap(object.list[[i]], pattern = "all", signaling = pathway.union, title = names(object.list)[i], width = 8, height = 16, color.heatmap = "OrRd")
ht2 = netAnalysis_signalingRole_heatmap(object.list[[i+1]], pattern = "all", signaling = pathway.union, title = names(object.list)[i+1], width = 8, height = 16, color.heatmap = "OrRd")
ht3 = netAnalysis_signalingRole_heatmap(object.list[[i+2]], pattern = "all", signaling = pathway.union, title = names(object.list)[i+2], width = 8, height = 16, color.heatmap = "OrRd")
ht4 = netAnalysis_signalingRole_heatmap(object.list[[i+3]], pattern = "all", signaling = pathway.union, title = names(object.list)[i+3], width = 8, height = 16, color.heatmap = "OrRd")
ht5 = netAnalysis_signalingRole_heatmap(object.list[[i+4]], pattern = "all", signaling = pathway.union, title = names(object.list)[i+4], width = 8, height = 16, color.heatmap = "OrRd")
ht6 = netAnalysis_signalingRole_heatmap(object.list[[i+5]], pattern = "all", signaling = pathway.union, title = names(object.list)[i+5], width = 8, height = 16, color.heatmap = "OrRd")
ht7 = netAnalysis_signalingRole_heatmap(object.list[[i+6]], pattern = "all", signaling = pathway.union, title = names(object.list)[i+6], width = 8, height = 16, color.heatmap = "OrRd")
draw(ht1 + ht2 + ht3 + ht4 + ht5 + ht6 + ht7, ht_gap = unit(0.5, "cm"))
