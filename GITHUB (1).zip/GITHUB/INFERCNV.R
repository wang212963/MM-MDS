#INFERCNV
# R version 4.1.0 INFERCNV version: 1.8.1
library(dplyr)
library(Seurat)
library(patchwork)
library(infercnv)
counts<-GetAssayData(MM_CELL,slot = 'counts')
head(counts)
Idents(MM_CELL)<-MM_CELL$orig.ident
levels(MM_CELL)
anno<-data.frame(Idents(MM_CELL))
tail(anno)
table(MM_CELL$orig.ident)
human_genes_pos <- read.delim("/path/to/your/file/human_genes_pos.txt", header=FALSE, row.names=1)
View(human_genes_pos)
infercnv_object = CreateInfercnvObject(raw_counts_matrix = counts,annotations_file = anno,delim = "\t",gene_order_file = human_genes_pos,min_max_counts_per_cell = c(100, +Inf),ref_group_names = c("HD_161","HD_162","HD_163","HD_164"))
infercnv_object = infercnv::run(infercnv_object,cutoff = 0.1, out_dir = "D:/MDS/ANALYSIS/SUBCLUSTER/MM cell/infercnv/MM CELL/",cluster_by_groups = T , k_obs_groups = 8, HMM = FALSE,denoise = TRUE)
