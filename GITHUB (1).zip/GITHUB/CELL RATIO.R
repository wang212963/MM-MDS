#CELLRATIO
table(Idents(MM_MDS_MERGE_NO_MDS),MM_MDS_MERGE_NO_MDS$STIM)# SEURAT OBJECT MM_MDS_MERGE or MM_MDS_MERGE_NO_MDS
Cellratio <- prop.table(table(Idents(MM_MDS_MERGE_NO_MDS),MM_MDS_MERGE_NO_MDS$STIM), margin = 2)

Cellratio <- as.data.frame(Cellratio)
library(ggplot2)
ggplot(Cellratio) + 
  geom_bar(aes(x =Var2, y= Freq, fill = Var1),stat = "identity",width = 0.7,size = 0.5,colour = '#222222')+ 
  theme_classic() +
  labs(x='Sample',y = 'Ratio')+
  scale_fill_manual(values = allcolour)+
  theme(panel.border = element_rect(fill=NA,color="black", size=0.5, linetype="solid"))
write.csv(Cellratio,file = "cellratio_stim.csv")
