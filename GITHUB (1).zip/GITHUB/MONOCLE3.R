#monocle3
# R version : 4.1.0 monocle3 version: 1.0.0
library(Signac)
library(Seurat)
library(SeuratWrappers)
library(monocle3) 
library(Matrix)
library(ggplot2)
library(patchwork)
lineage_cells=MM_MDS_MERGE_NO_MDS[,MM_MDS_MERGE_NO_MDS@meta.data$CELLTYPE %in% c("Plasma cell CD138+","Plasma cell CD138-","B cell","Pro-B","HSC","GMP","prMONO","CD14+ Monocyte","CD16+ Monocyte","cDC","pDC","Erythroblast","Erythrocyte","Neu_like MONO")]
lineage.cds <- as.cell_data_set(lineage_cells)
lineage.cds <- cluster_cells(cds = lineage.cds, reduction_method = "UMAP")
lineage.cds <- learn_graph(lineage.cds, use_partition = F,close_loop = T)
lineage.cds <- order_cells(lineage.cds, reduction_method = "UMAP")
plot_cells(lineage.cds, label_groups_by_cluster = FALSE, label_leaves = FALSE, label_branch_points = FALSE,label_cell_groups = F,label_roots = F,color_cells_by = "pseudotime",cell_size = 1,group_cells_by = "cluster")
saveRDS(lineage.cds,file = "HSC_TO_3_LINEAGE_MONOCLE3.rds")
a<-pseudotime(lineage.cds)
write.csv(a,file = "lineage_pseudotime.csv")
