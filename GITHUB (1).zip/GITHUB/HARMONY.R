#MERGE ALL
MM_MDS_MERGE <- merge(HD_161, y = c(HD_162,HD_163,HD_164,MM_012,MM_023,MM_042,MM_043,MDS_1,MDS_2,MDS_3,MDS_4,MDS_5,MM_MDS_1,MM_MDS_2,MM_MDS_3,MM_MDS_4),add.cell.ids = c("HD_161","HD_162","HD_163","HD_164","MM_012","MM_023","MM_042","MM_043","MDS_1","MDS_2","MDS_3","MDS_4","MDS_5","MM_MDS_1","MM_MDS_2","MM_MDS_3","MM_MDS_4"),project = "MM_MDS_ALL")
MM_MDS_MERGE_NO_MDS <- merge(HD_161, y = c(HD_162,HD_163,HD_164,MM_012,MM_023,MM_042,MM_043,MM_MDS_1,MM_MDS_2,MM_MDS_3,MM_MDS_4),add.cell.ids = c("HD_161","HD_162","HD_163","HD_164","MM_012","MM_023","MM_042","MM_043","MM_MDS_1","MM_MDS_2","MM_MDS_3","MM_MDS_4"),project = "MM_MDS_ALL_NO_MDS")
# SEURAT OBJECT: MM_MDS_MERGE or MM_MDS_MERGE_NO_MDS
# R VERSION : 4.4.0 SEURAT VERSION : 4.4.0 HARMONY VERSION 1.2.3
MM_MDS_MERGE <- NormalizeData(MM_MDS_MERGE) %>% FindVariableFeatures() %>% ScaleData() %>% RunPCA(verbose = FALSE) 
MM_MDS_MERGE <- RunHarmony(MM_MDS_MERGE, group.by.vars = "orig.ident")
MM_MDS_MERGE <- RunUMAP(MM_MDS_MERGE, reduction = "harmony", dims = 1:10)
MM_MDS_MERGE <- FindNeighbors(MM_MDS_MERGE, reduction = "harmony", dims = 1:10) %>% FindClusters()
MM_MDS_MERGE<- FindClusters(MM_MDS_MERGE, resolution = 1.5)  # Resolution may change for carefully cell type annotation
# R VERSION : 4.1.0 SEURAT VERSION : 4.1.0 HARMONY VERSION 0.1.0
MM_MDS_MERGE_NO_MDS <- NormalizeData(MM_MDS_MERGE_NO_MDS) %>% FindVariableFeatures() %>% ScaleData() %>% RunPCA(verbose = FALSE) 
MM_MDS_MERGE_NO_MDS <- RunHarmony(MM_MDS_MERGE_NO_MDS, group.by.vars = "orig.ident")
MM_MDS_MERGE_NO_MDS <- RunUMAP(MM_MDS_MERGE_NO_MDS, reduction = "harmony", dims = 1:30)
MM_MDS_MERGE_NO_MDS <- FindNeighbors(MM_MDS_MERGE_NO_MDS, reduction = "harmony", dims = 1:30) %>% FindClusters()
MM_MDS_MERGE_NO_MDS <- FindClusters(MM_MDS_MERGE_NO_MDS, resolution = 1.5) # Resolution may change for carefully cell type annotation
#CELL TYPE ANNOTATION
# SEURAT OBJECT: MM_MDS_MERGE or MM_MDS_MERGE_NO_MDS
# MM_MDS_MERGE_NO_MDS as an example
new.cluster.ids <- c( "CD4+ T","Neu_like MONO", "CD8+ T","CD8+ T","Plasma cell CD138+","Plasma cell CD138-","B cell","NK","GMP","Erythroblast","CD14+ Monocyte","Erythrocyte", "Plasma cell CD138-","Erythrocyte","GMP","CD14+ Monocyte","prMONO","Erythroblast","Neutrophil","CD4+ T","CD16+ Monocyte","Plasma cell CD138+", "Plasma cell CD138+","Erythroblast","Plasma cell CD138-","Neutrophil","Plasma cell CD138+","Pro-B","HSC","MKP","CD14+ Monocyte","Plasma cell CD138-", "Plasma cell CD138+","Plasma cell CD138+","cDC","CD4+ T","pDC","Plasma cell CD138+","Plasma cell CD138-","Erythrocyte","CD8+ T","CD14+ Monocyte", "GMP","Neutrophil","Stromal cell","Plasma cell CD138+","Plasma cell CD138+","Erythroblast","B cell") 
names(new.cluster.ids) <- levels(MM_MDS_MERGE_NO_MDS)
MM_MDS_MERGE_NO_MDS <- RenameIdents(MM_MDS_MERGE_NO_MDS, new.cluster.ids)
MM_MDS_MERGE_NO_MDS[["CELLTYPE"]]<-MM_MDS_MERGE_NO_MDS@active.ident
#GROUP ANNOTATION
new.cluster.ids=c('HD','HD','HD','HD','MM_high_risk','MM_high_risk','MM_low_risk','MM_low_risk','MM_MDS_low_risk','MM_MDS_high_risk','MM_MDS_low_risk','MM_MDS_high_risk')
Idents(MM_MDS_MERGE_NO_MDS)<-MM_MDS_MERGE_NO_MDS@meta.data$orig.ident
levels(MM_MDS_MERGE_NO_MDS)
table(MM_MDS_MERGE_NO_MDS$orig.ident)
names(new.cluster.ids) <- levels(MM_MDS_MERGE_NO_MDS)
MM_MDS_MERGE_NO_MDS <- RenameIdents(MM_MDS_MERGE_NO_MDS, new.cluster.ids)
levels(MM_MDS_MERGE_NO_MDS)
MM_MDS_MERGE_NO_MDS[["STIM"]]<-MM_MDS_MERGE_NO_MDS@active.ident
table(MM_MDS_MERGE_NO_MDS$STIM)
DimPlot(MM_MDS_MERGE_NO_MDS,label = T,split.by = "STIM")
Idents(MM_MDS_MERGE_NO_MDS)='CELLTYPE'
new.cluster.ids=c('HD','HD','HD','HD','MM_high_risk','MM_high_risk','MM_low_risk','MM_low_risk','MDS_low_risk','MDS_high_risk','MDS_low_risk','MDS_high_risk','MDS_high_risk','MM_MDS_low_risk','MM_MDS_high_risk','MM_MDS_low_risk','MM_MDS_high_risk')
Idents(MM_MDS_MERGE)<-MM_MDS_MERGE@meta.data$orig.ident
levels(MM_MDS_MERGE)
table(MM_MDS_MERGE$orig.ident)
names(new.cluster.ids) <- levels(MM_MDS_MERGE)
MM_MDS_MERGE <- RenameIdents(MM_MDS_MERGE, new.cluster.ids)
levels(MM_MDS_MERGE)
MM_MDS_MERGE[["STIM"]]<-MM_MDS_MERGE@active.ident
table(MM_MDS_MERGE$STIM)
DimPlot(MM_MDS_MERGE,label = T,split.by = "STIM")
Idents(MM_MDS_MERGE)='CELLTYPE'
