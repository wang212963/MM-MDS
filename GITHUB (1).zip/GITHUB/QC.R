#??????
library(dplyr)
library(Seurat)

library(patchwork)
library(monocle3)
memory.limit(100000000)
library(harmony)
library(SeuratData)
library(scDblFinder)
library(BiocParallel)
library(ggplot2)
library(ggpubr)
library(monocle)
library(dplyr)
library(patchwork)
library(infercnv)
library(CytoTRACE2)
library(devtools)
library(ggplot2)
library(msigdbr)
library(GSVA)
library(pheatmap)
library(limma)
library(Matrix)
library(CellChat)
library(tidyverse)
library(ggalluvial)


#input datasets
HD_161 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/GSE120221_RAW_HD/161")
HD_162 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/GSE120221_RAW_HD/162")
HD_163 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/GSE120221_RAW_HD/163")
HD_164 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/GSE120221_RAW_HD/164")

MM_012 <- Read10X_h5(filename = "/home/data/bio2/Desktop/mds_review/GSE189460_RAW_MM/GSM5702263_MM012_filtered_feature_bc_matrix.h5")
MM_023 <- Read10X_h5(filename = "/home/data/bio2/Desktop/mds_review/GSE189460_RAW_MM/GSM5702264_MM023_filtered_feature_bc_matrix.h5")
MM_042 <- Read10X_h5(filename = "/home/data/bio2/Desktop/mds_review/GSE189460_RAW_MM/GSM5702265_MM042_filtered_feature_bc_matrix.h5")
MM_043 <- Read10X_h5(filename = "/home/data/bio2/Desktop/mds_review/GSE189460_RAW_MM/GSM5702266_MM043_filtered_feature_bc_matrix.h5")

MDS_1 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/CAILAB_MDS/CAILAB_MDS/MDS1")
MDS_2 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/CAILAB_MDS/CAILAB_MDS/MDS2")
MDS_3 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/CAILAB_MDS/CAILAB_MDS/MDS3")
MDS_4 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/CAILAB_MDS/CAILAB_MDS/MDS4")
MDS_5 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/CAILAB_MDS/CAILAB_MDS/MDS5")

MM_MDS_1 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/MM_MDS_REVIEW/mds_1")
MM_MDS_2 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/MM_MDS_REVIEW/mds_2")
MM_MDS_3 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/MM_MDS_REVIEW/mds_3")
MM_MDS_4 <- Read10X(data.dir = "/home/data/bio2/Desktop/mds_review/MM_MDS_REVIEW/mds_4")

#CREAT SEURAT OBJECT
HD_161 <- CreateSeuratObject(counts = HD_161, project= "HD_161", min.cells = 3, min.features = 200)
HD_162 <- CreateSeuratObject(counts = HD_162, project= "HD_162", min.cells = 3, min.features = 200)
HD_163 <- CreateSeuratObject(counts = HD_163, project= "HD_163", min.cells = 3, min.features = 200)
HD_164 <- CreateSeuratObject(counts = HD_164, project= "HD_164", min.cells = 3, min.features = 200)

MM_012 <- CreateSeuratObject(counts = MM_012, project= "MM_012", min.cells = 3, min.features = 200)
MM_023 <- CreateSeuratObject(counts = MM_023, project= "MM_023", min.cells = 3, min.features = 200)
MM_042 <- CreateSeuratObject(counts = MM_042, project= "MM_042", min.cells = 3, min.features = 200)
MM_043 <- CreateSeuratObject(counts = MM_043, project= "MM_043", min.cells = 3, min.features = 200)

MDS_1 <- CreateSeuratObject(counts = MDS_1, project= "MDS_1", min.cells = 3, min.features = 200)
MDS_2 <- CreateSeuratObject(counts = MDS_2, project= "MDS_2", min.cells = 3, min.features = 200)
MDS_3 <- CreateSeuratObject(counts = MDS_3, project= "MDS_3", min.cells = 3, min.features = 200)
MDS_4 <- CreateSeuratObject(counts = MDS_4, project= "MDS_4", min.cells = 3, min.features = 200)
MDS_5 <- CreateSeuratObject(counts = MDS_5, project= "MDS_5", min.cells = 3, min.features = 200)

MM_MDS_1 <- CreateSeuratObject(counts = MM_MDS_1, project= "MM_MDS_1", min.cells = 3, min.features = 200)
MM_MDS_2 <- CreateSeuratObject(counts = MM_MDS_2, project= "MM_MDS_2", min.cells = 3, min.features = 200)
MM_MDS_3 <- CreateSeuratObject(counts = MM_MDS_3, project= "MM_MDS_3", min.cells = 3, min.features = 200)
MM_MDS_4 <- CreateSeuratObject(counts = MM_MDS_4, project= "MM_MDS_4", min.cells = 3, min.features = 200)

#quality control
HD_161[["percent.mt"]] <- PercentageFeatureSet(HD_161,pattern = "^MT-")
HD_161[["percent.ribo"]] <- PercentageFeatureSet(HD_161, pattern = "^RP[SL]")
VlnPlot(HD_161, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
HD_161 <- subset(HD_161, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 15& percent.ribo < 60)

HD_162[["percent.mt"]] <- PercentageFeatureSet(HD_162,pattern = "^MT-")
HD_162[["percent.ribo"]] <- PercentageFeatureSet(HD_162, pattern = "^RP[SL]")
VlnPlot(HD_162, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
HD_162 <- subset(HD_162, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 15& percent.ribo < 60)

HD_163[["percent.mt"]] <- PercentageFeatureSet(HD_163,pattern = "^MT-")
HD_163[["percent.ribo"]] <- PercentageFeatureSet(HD_163, pattern = "^RP[SL]")
VlnPlot(HD_163, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
HD_163 <- subset(HD_163, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 15& percent.ribo < 60)

HD_164[["percent.mt"]] <- PercentageFeatureSet(HD_164,pattern = "^MT-")
HD_164[["percent.ribo"]] <- PercentageFeatureSet(HD_164, pattern = "^RP[SL]")
VlnPlot(HD_164, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
HD_164 <- subset(HD_164, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 15& percent.ribo < 60)

MM_012[["percent.mt"]] <- PercentageFeatureSet(MM_012,pattern = "^MT-")
MM_012[["percent.ribo"]] <- PercentageFeatureSet(MM_012, pattern = "^RP[SL]")
VlnPlot(MM_012, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_012 <- subset(MM_012, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MM_023[["percent.mt"]] <- PercentageFeatureSet(MM_023,pattern = "^MT-")
MM_023[["percent.ribo"]] <- PercentageFeatureSet(MM_023, pattern = "^RP[SL]")
VlnPlot(MM_023, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_023 <- subset(MM_023, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MM_042[["percent.mt"]] <- PercentageFeatureSet(MM_042,pattern = "^MT-")
MM_042[["percent.ribo"]] <- PercentageFeatureSet(MM_042, pattern = "^RP[SL]")
VlnPlot(MM_042, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_042 <- subset(MM_042, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MM_043[["percent.mt"]] <- PercentageFeatureSet(MM_043,pattern = "^MT-")
MM_043[["percent.ribo"]] <- PercentageFeatureSet(MM_043, pattern = "^RP[SL]")
VlnPlot(MM_043, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_043 <- subset(MM_043, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MDS_1[["percent.mt"]] <- PercentageFeatureSet(MDS_1,pattern = "^MT-")
MDS_1[["percent.ribo"]] <- PercentageFeatureSet(MDS_1, pattern = "^RP[SL]")
VlnPlot(MDS_1, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MDS_1 <- subset(MDS_1, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MDS_2[["percent.mt"]] <- PercentageFeatureSet(MDS_2,pattern = "^MT-")
MDS_2[["percent.ribo"]] <- PercentageFeatureSet(MDS_2, pattern = "^RP[SL]")
VlnPlot(MDS_2, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MDS_2 <- subset(MDS_2, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 80)

MDS_3[["percent.mt"]] <- PercentageFeatureSet(MDS_3,pattern = "^MT-")
MDS_3[["percent.ribo"]] <- PercentageFeatureSet(MDS_3, pattern = "^RP[SL]")
VlnPlot(MDS_3, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MDS_3 <- subset(MDS_3, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MDS_4[["percent.mt"]] <- PercentageFeatureSet(MDS_4,pattern = "^MT-")
MDS_4[["percent.ribo"]] <- PercentageFeatureSet(MDS_4, pattern = "^RP[SL]")
VlnPlot(MDS_4, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MDS_4 <- subset(MDS_4, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MDS_5[["percent.mt"]] <- PercentageFeatureSet(MDS_5,pattern = "^MT-")
MDS_5[["percent.ribo"]] <- PercentageFeatureSet(MDS_5, pattern = "^RP[SL]")
VlnPlot(MDS_5, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MDS_5 <- subset(MDS_5, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MM_MDS_1[["percent.mt"]] <- PercentageFeatureSet(MM_MDS_1,pattern = "^MT-")
MM_MDS_1[["percent.ribo"]] <- PercentageFeatureSet(MM_MDS_1, pattern = "^RP[SL]")
VlnPlot(MM_MDS_1, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_MDS_1 <- subset(MM_MDS_1, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MM_MDS_2[["percent.mt"]] <- PercentageFeatureSet(MM_MDS_2,pattern = "^MT-")
MM_MDS_2[["percent.ribo"]] <- PercentageFeatureSet(MM_MDS_2, pattern = "^RP[SL]")
VlnPlot(MM_MDS_2, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_MDS_2 <- subset(MM_MDS_2, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MM_MDS_3[["percent.mt"]] <- PercentageFeatureSet(MM_MDS_3,pattern = "^MT-")
MM_MDS_3[["percent.ribo"]] <- PercentageFeatureSet(MM_MDS_3, pattern = "^RP[SL]")
VlnPlot(MM_MDS_3, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_MDS_3 <- subset(MM_MDS_3, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)

MM_MDS_4[["percent.mt"]] <- PercentageFeatureSet(MM_MDS_4,pattern = "^MT-")
MM_MDS_4[["percent.ribo"]] <- PercentageFeatureSet(MM_MDS_4, pattern = "^RP[SL]")
VlnPlot(MM_MDS_4, features = c("nFeature_RNA", "nCount_RNA", "percent.mt","percent.ribo"), ncol = 4)
MM_MDS_4 <- subset(MM_MDS_4, subset = nFeature_RNA > 200 & nFeature_RNA < 7500 & percent.mt < 75& percent.ribo < 60)