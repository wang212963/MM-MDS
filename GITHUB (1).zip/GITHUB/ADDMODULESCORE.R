#addmodulescore
MM_CELL= MM_MDS_MERGE_NO_MDS[,MM_MDS_MERGE_NO_MDS@meta.data$CELLTYPE_2 %in% c("Plasma cell CD138+")]
geneset=msigdbr("Homo sapiens",'C5')%>%filter(gs_name=="GOBP_CELL_GROWTH")%>%distinct(gene_symbol)%>%pull(gene_symbol)
geneset=list(GOBP_CELL_GROWTH=geneset)
geneset
score=AddModuleScore(MM_CELL,geneset)
score@meta.data['GOBP_CELL_GROWTH']=score@meta.data$Cluster1
FeaturePlot(score,'GOBP_CELL_GROWTH',min.cutoff = 0.01)
score
VlnPlot(score,features = 'GOBP_CELL_GROWTH', pt.size = 0, adjust = 2,group.by = "STIM")
p1<-ggviolin(score@meta.data, x="STIM", y="GOBP_CELL_GROWTH", width = 0.6, 
             color = "black",#??��??ɫ
             fill="STIM",#????
             palette = colour,
             add = 'mean_sd',
             #palette =c("#E7B800", "#00AFBB"),#??????ɫ
             xlab = F, #????ʾx???ı?ǩ
             bxp.errorbar=T,#??ʾ??????
             bxp.errorbar.width=0.5, #????????С
             size=1, #????ͼ???ߵĴ?ϸ
             outlier.shape=NA, #????ʾoutlier
             legend = "right") #ͼ??
p1
my_comparisons <- list(c("MM_MDS_low_risk","MM_MDS_high_risk"),c("HD","MM_low_risk"),c("HD","MM_high_risk"),c("MM_low_risk","MM_high_risk"),c("MM_high_risk","MM_MDS_low_risk"),c("MM_high_risk","MM_MDS_high_risk"))
p1+stat_compare_means(comparisons = my_comparisons,
                      method = "wilcox.test")
library(ggpubr)
colour=c("#DC143C","#0000FF","#20B2AA","#FFA500","#9370DB","#98FB98","#F08080","#1E90FF","#7CFC00","#FFFF00",  
         "#808000","#FF00FF","#FA8072","#7B68EE","#9400D3","#800080","#A0522D","#D2B48C","#D2691E","#87CEEB","#40E0D0","#5F9EA0",
         "#FF1493","#0000CD","#008B8B","#FFE4B5","#8A2BE2","#228B22","#E9967A","#4682B4","#32CD32","#F0E68C","#FFFFE0","#EE82EE",
         "#FF6347","#6A5ACD","#9932CC","#8B008B","#8B4513","#DEB887")

#memory.limit(10000000)
geneset=msigdbr("Homo sapiens",'C2')%>%filter(gs_name=="KEGG_PATHWAYS_IN_CANCER")%>%distinct(gene_symbol)%>%pull(gene_symbol)
geneset=list(KEGG_PATHWAYS_IN_CANCER=geneset)
geneset
#???л??򼯴???
score=AddModuleScore(MM_CELL,geneset)
score@meta.data['KEGG_PATHWAYS_IN_CANCER']=score@meta.data$Cluster1
#???????ӻ?
FeaturePlot(score,'KEGG_PATHWAYS_IN_CANCER',min.cutoff = 0.05)
score
VlnPlot(score,features = 'KEGG_PATHWAYS_IN_CANCER', pt.size = 0, adjust = 2,group.by = "STIM")
P1<-ggviolin(score@meta.data, x="STIM", y="KEGG_PATHWAYS_IN_CANCER", width = 0.6, 
             color = "black",#??��??ɫ
             fill="STIM",#????
             palette = colour,
             add = 'mean_sd',
             #palette =c("#E7B800", "#00AFBB"),#??????ɫ
             xlab = F, #????ʾx???ı?ǩ
             bxp.errorbar=T,#??ʾ??????
             bxp.errorbar.width=0.5, #????????С
             size=1, #????ͼ???ߵĴ?ϸ
             outlier.shape=NA, #????ʾoutlier
             legend = "right") #ͼ??
P1
library(ggpubr)
colour=c("#DC143C","#0000FF","#20B2AA","#FFA500","#9370DB","#98FB98","#F08080","#1E90FF","#7CFC00","#FFFF00",  
         "#808000","#FF00FF","#FA8072","#7B68EE","#9400D3","#800080","#A0522D","#D2B48C","#D2691E","#87CEEB","#40E0D0","#5F9EA0",
         "#FF1493","#0000CD","#008B8B","#FFE4B5","#8A2BE2","#228B22","#E9967A","#4682B4","#32CD32","#F0E68C","#FFFFE0","#EE82EE",
         "#FF6347","#6A5ACD","#9932CC","#8B008B","#8B4513","#DEB887")
my_comparisons <- list(c("MM_MDS_low_risk","MM_MDS_high_risk"),c("HD","MM_low_risk"),c("HD","MM_high_risk"),c("MM_low_risk","MM_high_risk"),c("MM_high_risk","MM_MDS_low_risk"),c("MM_high_risk","MM_MDS_high_risk"))
P1+stat_compare_means(comparisons = my_comparisons,
                      method = "wilcox.test")


# COMPARE SIMILARITY OF Neu_like_MONO cells in MM_MDS and MDS
Neu_like_MONO_GENES_IN_MDS_features <- list(c("CXCL8","G0S2","IL1R2","CMTM2","IFITM2","NAMPT","TGM3","MME","LITAF","FCGR3B","ADGRG3","ALPL","CSF3R","LIMK2","AQP9","XPO6","S100A12","MGAM","PROK2","MMP9","DYSF","AL034397.3","NIBAN1","DOCK4","KCNJ15","TNFRSF10C","ALOX5AP","LUCAT1","ARHGAP15"))
NEU_LIKE_MONO_IN_ALL=MM_MDS_MERGE[,MM_MDS_MERGE@meta.data$CELLTYPE %in% c("Neu_like_MONO")]
sce2 <- AddModuleScore(NEU_LIKE_MONO_IN_ALL,
                       features= Neu_like_MONO_GENES_IN_MDS_features,
                       ctrl = 100,
                       name = "Neu_like_MONO_GENES_IN_MDS_features_SCORE")
head(sce2@meta.data$Neu_like_MONO_GENES_IN_MDS_features_SCORE1)
p1<-ggboxplot(sce2@meta.data, x="STIM", y="Neu_like_MONO_GENES_IN_MDS_features_SCORE1", width = 0.6, 
              color = "black",#??��??ɫ
              fill="STIM",#????
              palette = allcolour,
              #palette =c("#E7B800", "#00AFBB"),#??????ɫ
              xlab = F, #????ʾx???ı?ǩ
              bxp.errorbar=T,#??ʾ??????
              bxp.errorbar.width=0.5, #????????С
              size=1, #????ͼ???ߵĴ?ϸ
              outlier.shape=NA, #????ʾoutlier
              legend = "right") #ͼ??
p1

my_comparisons <- list(c("MM_MDS_low_risk","MM_MDS_high_risk"),c("MDS_low_risk","MDS_high_risk"))
p1+stat_compare_means(comparisons = my_comparisons,
                      method = "wilcox.test")